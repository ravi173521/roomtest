package com.a.roombooking;

public class Utils {
    public static String SHREF="MB";
}
